WANTED PORTFOLIO
================

Open index.html in any modern browser.

CONTACT
-------
Gmail: adityavaibhav579@gmail.com
Discord: 8fqg

NOTES
-----
- The Discord button currently uses https://discord.com/users/8fqg.
- If 8fqg is a Discord username rather than a user ID/profile URL, replace that href with your actual Discord profile link or server invite.
- The portfolio is a single-file website; the assets folders are included for future images/icons.
